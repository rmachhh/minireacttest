React Mini Take Home Test

Setup:

1. to run the project you would need to install the packages.
2. run "npm install" to install all necessary packages.
3. after installation, run the project using "npm run dev"

Prerequisites:

1. Node

Testing:

1. run "npm run test"

What would improve:

1. Server-side pagination if we are accessing our own created data that allows us to implement pages and limits
2. Advance State Management i would replace the usePosts hook logic with tanstack query.
3. Virtualization so that if the lists grow from 30 to 30,000 it will only render 5-10 items currently visible in the viewport.
