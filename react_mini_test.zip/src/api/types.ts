export interface Post {
  id: number;
  title: string;
  content: string;
  expandable?: boolean;
}
